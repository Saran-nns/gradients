from gradients import *
import logging

__author__ = "Saranraj Nambusubramaniyan"
__version__ = "0.0.1"

logging.basicConfig(level=logging.INFO)